﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class FloodDatabase : System.Web.UI.Page
{
    string fileLocation, table, dbconnectionString;
    int numberOfValues;
    string filename = "Teacher.txt";
    bool uploaded = false;
    protected void Page_Load(object sender, EventArgs e)
    {
        dbconnectionString = "Data Source=stusql;Integrated Security=true";
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        FileUsageForDatabase fileuse = new FileUsageForDatabase();
        if (ChoiceBox.SelectedItem.Text == "Classroom")
        {

                table = "Classroom";
                numberOfValues = 4;
                fileLocation = "F:\\Work\\BackendWeb\\AlienCram\\App_Code\\Classroom.txt";
                fileuse.fillDatabase(fileLocation, table, dbconnectionString, numberOfValues);
        }
        else if (ChoiceBox.SelectedItem.Text == "Instructor")
        {
                table = "Instructor";
                numberOfValues = 2;
                fileLocation = "F:\\Work\\BackendWeb\\AlienCram\\App_Code\\Teacher.txt";
                fileuse.fillDatabase(fileLocation, table, dbconnectionString, numberOfValues);
        }
    }

    protected void ChoiceBox_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}