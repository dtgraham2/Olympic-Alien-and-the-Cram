﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
public partial class TableM : System.Web.UI.Page
{
    string[,] Schedule = new string[5, 3];
    string[,] Tables = new String[1001, 30];
    protected void Page_Load(object sender, EventArgs e)
    {
        //string[,] Tables = new String[1001, 30];
        string dbConnection = "Data Source=stusql; Integrated Security=True;";
            
            DatabaseAccess Data = new DatabaseAccess();
            string keyword = "studentID";
            string filter = (string)Session["ID"];
        string[] rows = { "studentID", "firstName", "LastName", "SSN", "Birthday", "CurrentQuarter", "GPA" };
        string tablename = "currentStudents";
        bool isNumber = true;
        try
        {
            int filtCheck = int.Parse(filter);
            if (filter == null)
            {
                filter = "1";
            }
            Tables = Data.SearchAllInteger(dbConnection,  rows, tablename, filter, keyword);
            Response.Write("<center>");
            Response.Write("<table border='1' width ='55%' >");
            Response.Write("<tr>");
            Response.Write("<th>Student ID</th>");
            Response.Write("<th>First Name</th>");
            Response.Write("<th>Last Name</th>");
            Response.Write("<th>SSN</th>");
            Response.Write("<th>Birthday</th>");
            Response.Write("<th>Current Quarter</th>");
            Response.Write("<th>GPA</th>");
            Response.Write("</tr>");
            for (int k = 0; k < (1000); ++k)
            {
                for (int i = 0; i < (rows.Length + 1); ++i)
                {
                    Response.Write(Tables[k, i]);
                }
            }
            Response.Write("</table>");
        }
        catch
        {
            isNumber = false;
            Response.Write("WooHoo!");
            Response.Redirect("StudentLogin.aspx");
        }
        keyword = "studentID";
        filter = (string)Session["ID"];
        int classesaWeek = 0;
        int day = 0;
        //bool isNumber = true;
        //try
        //{
        bool checks = true;
        int j = 0;
        string[] rows2 = { "CourseID", "ClassName", "HoursPerWeek", "ClassNumber", "LabNumber", "QuarterTaken", "RoomNumber" };
        Tables = Data.SearchAllSchedule(dbConnection, rows, tablename, keyword, filter);
        string[,] Classes = new String[1001, 30];
        Classes = Data.SearchAllSchedule(dbConnection, rows2, "Classes", rows2[5], Tables[0, 6]);
        string[] Times = { "10:30-12:20", "12:30-2:20", "2:40-4:30" };
        string[] Days = { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday" };
        while (checks == true)
        {
            try
            {
                int hoursForClass;
                hoursForClass = int.Parse(Classes[j, 3]);

                if (hoursForClass == 10)
                {
                    classesaWeek = 5;
                }
                if (hoursForClass == 6)
                {
                    classesaWeek = 3;
                }
                if (hoursForClass == 4)
                {
                    classesaWeek = 2;
                }
                if (hoursForClass == 2)
                {
                    classesaWeek = 1;
                }

            }
            catch
            {
                return;
            }
            while (classesaWeek != 0)
            {

                if (Schedule[day, 0] == null)
                {
                    Schedule[day, 0] = Days[day] + "\t" + Times[0] + "\t" + Classes[j, 2] + "\t" + Classes[j, 7];

                }
                else if (Schedule[day, 1] == null)
                {
                    Schedule[day, 1] = Days[day] + "\t" + Times[1] + "\t" + Classes[j, 2] + "\t" + Classes[j, 7];

                }
                else if (Schedule[day, 2] == null)
                {
                    Schedule[day, 2] = Days[day] + "\t" + Times[2] + "\t" + Classes[j, 2] + "\t" + Classes[j, 7];

                }
                day++;
                classesaWeek--;


            }
            j++;
            if (Classes[j, 3] == null)
                checks = false;
            day = 0;
        }
        for (int p = 0; p <= 4; p++)
        {
            for (int v = 0; v <= 2; v++)
            {
                if (Schedule[p, v] != null)
                {
                    Response.Write(Schedule[p, v]);
                    Response.Write("<br>");
                }
            }
        }
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();
        dt.Columns.AddRange(new DataColumn[7] {
    new DataColumn("studentID"),
    new DataColumn("firstName"),
    new DataColumn("LastName"),
     new DataColumn("SSN"),
        new DataColumn("Birthday"),
        new DataColumn("CurrentQuarter"),
        new DataColumn("GPA")});

                dt.Rows.Add(Tables[0, 0], Tables[0, 1], Tables[0, 2], Tables[0, 3], Tables[0, 4], Tables[0, 5], Tables[0, 6]);
        for (int p = 0; p <= 4; p++)
        {
            for (int v = 0; v <= 2; v++)
            {
                if (Schedule[p, v] != null)
                {
                    dt.Rows.Add(Schedule[p, v]);
                }
            }
        }
        StringBuilder sb = new StringBuilder();

        sb.Append("<table border = '1'>"); 
        sb.Append("<tr>");
        sb.Append("<th></th>");
        foreach (DataColumn column in dt.Columns)
        {
            sb.Append("<th style = 'background-color: #D20B0C;color:#ffffff'>");
            sb.Append(column.ColumnName);
            sb.Append("</th>");
        }
        sb.Append("</tr>");
        foreach (DataRow row in dt.Rows)
        {
            sb.Append("<tr>");
            foreach (DataColumn column in dt.Columns)
            {
                sb.Append("<td>");
                sb.Append(row[column]);
                sb.Append("</td>");
            }
           sb.Append("</tr>");
        }
        sb.Append("</table>");
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=Export.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";
        string style = @"<style> .textmode { } </style>";
        Response.Write(style);
        Response.Output.Write(sb.ToString());
        Response.Flush();
        Response.End();
    }
}