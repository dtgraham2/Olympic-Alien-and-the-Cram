﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Registered : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string dbConnection = "Data Source=stusql; Integrated Security=True;";
        string[] Values = new string[2];
        InsertInto Data = new InsertInto();
        Values[0] = (string)Session["Name"];
        Values[1] = (string)Session["Course"];
        string tablename = "NewStudents";
        if (Values[0] != null && Values[1] != null)
        {
            Data.InsertIntoDB(dbConnection, Values, tablename);
        }
        else
        {
            Response.Redirect("Default.aspx");
        }

    }
    }